﻿namespace $safeprojectname$
{
    internal static class EVENTSOURCING
    {
        internal const bool ISACTIVE = true;
    }
}
