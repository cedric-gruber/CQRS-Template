﻿using $ext_safeprojectname$.Command.Domain.TodoList;

namespace $safeprojectname$.Commands.TodoListResponses
{
    public class ChangeTodoListNameResponse
    {
        public TodoList Aggregate { get; set; }
    }
}
