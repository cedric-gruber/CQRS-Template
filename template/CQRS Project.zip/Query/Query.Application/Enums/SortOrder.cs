﻿namespace $safeprojectname$.Enums
{
    public enum SortOrder
    {
        Ascending = 1,
        Descending = 2
    }
}
