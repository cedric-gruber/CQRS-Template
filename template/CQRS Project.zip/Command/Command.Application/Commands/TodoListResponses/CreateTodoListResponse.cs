﻿using $ext_safeprojectname$.Command.Domain.TodoList;

namespace $safeprojectname$.Commands.TodoListResponses
{
    public class CreateTodoListResponse
    {
        public TodoList Aggregate { get; set; }
    }
}
