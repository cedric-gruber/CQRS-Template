﻿using System;

namespace $safeprojectname$.Models.TodoListModels.ViewModels
{
    public class AllTodosViewModel
    {
        public Guid Id { get; set; }
        public string Name { get; set; }
        public string ListName { get; set; }
    }
}
