﻿namespace $safeprojectname$.Enums.TodoList
{
    public enum AllTodosSortBy
    {
        Name = 1,
        ListName = 2
    }
}
