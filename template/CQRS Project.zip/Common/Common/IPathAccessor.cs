﻿namespace $safeprojectname$
{
    public interface IPathAccessor
    {
        public string GetRootPath();
        public string GetFilePath();
    }
}
