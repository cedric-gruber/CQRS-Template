﻿using System;

namespace $safeprojectname$
{
    class Program
    {
        static void Main(string[] args)
        {
            // This class is used for your tests during the development
            Console.WriteLine("Hello from Test Class!");
        }
    }
}
