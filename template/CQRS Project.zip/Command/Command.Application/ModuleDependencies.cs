﻿using Microsoft.Extensions.DependencyInjection;

namespace $safeprojectname$
{
    public static class ModuleDependencies
    {
        public static void AddCommandApplicationModuleDependencies(this IServiceCollection services)
        {

        }
    }
}
