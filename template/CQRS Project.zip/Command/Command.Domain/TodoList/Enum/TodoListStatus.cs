﻿namespace $safeprojectname$.TodoList.Enum
{
    public enum TodoListStatus
    {
        New = 1, 
        Pending = 2, 
        InProgress = 3, 
        Completed = 4
    }
}
