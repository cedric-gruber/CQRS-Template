﻿using $ext_safeprojectname$.Command.Domain.TodoList;

namespace $safeprojectname$.Commands.TodoListResponses
{
    public class CreateTodoResponse
    {
        public Todo Aggregate { get; set; }
    }
}
