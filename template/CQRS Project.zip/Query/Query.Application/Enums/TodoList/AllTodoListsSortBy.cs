﻿namespace $safeprojectname$.Enums.TodoList
{
    public enum AllTodoListsSortBy
    {
        Name = 1,
        NumberOfTodos = 2
    }
}
