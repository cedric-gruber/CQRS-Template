﻿namespace $safeprojectname$.BaseComponents
{
    public interface IDomainEvent
    {
    }
}
