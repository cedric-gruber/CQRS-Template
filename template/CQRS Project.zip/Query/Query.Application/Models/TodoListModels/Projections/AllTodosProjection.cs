﻿using System;

namespace $safeprojectname$.Models.TodoListModels.Projections
{
    public class AllTodosProjection
    {
        public Guid Id { get; set; }
        public string Name { get; set; }
        public string ListName { get; set; }
    }
}
