﻿using $ext_safeprojectname$.Command.Domain.TodoList;

namespace $safeprojectname$.Commands.TodoListResponses
{
    public class CompleteTodoResponse
    {
        public Todo Aggregate { get; set; }
    }
}
