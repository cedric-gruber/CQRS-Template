﻿using $ext_safeprojectname$.Command.Domain.TodoList;

namespace $safeprojectname$.Commands.TodoListResponses
{
    public class RemoveTodoResponse
    {
        public Todo Aggregate { get; set; }
    }
}
