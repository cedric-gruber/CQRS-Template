﻿using Microsoft.Extensions.DependencyInjection;

namespace $safeprojectname$
{
    public static class ModuleDependencies
    {
        public static void AddCommandDomainModuleDependencies(this IServiceCollection services)
        {

        }
    }
}
